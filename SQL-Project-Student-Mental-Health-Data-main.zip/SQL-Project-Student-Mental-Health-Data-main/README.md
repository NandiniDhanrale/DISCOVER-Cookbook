# SQL-Project-Student-Mental-Health-Data

I load the data in MySQL Workbench database and explore it using SQL.
I have attached the SQL query file down below so, everyone can explore it. I have performed a detailed Exploratory Data Analysis (EDA) in this project.
